import Foundation

//VAMOS A DEFINIR LAS DISTINTAS ESTRUCTURAS

//Definimos la estructura Client y sus propiedades.
struct Client {
    let name: String
    let age: Int
    let height: Float
}

//Definimos la estructura Reservation
struct Reservation {
    let id: Int
    let hotelName: String
    let clients: [Client]
    let duration: Int
    let price: Double
    let includesBreakfast: Bool
}

//Definimos la estructura ReservationError
enum ReservationError: Error {
    case duplicateID
    case reservationNotFoundClient
    case reservationNotFound
}

class HotelReservationManager {
    private var reservations: [Reservation] //Propiedad que es una array que almacena las reservas realizadas
    private var reservationIDCounter: Int //Propiedad para llevar la cuenta del último ID asignado
    
    //Creamos constructores para inicializarlo
    init() {
        self.reservations = []
        self.reservationIDCounter = 1
    }
    
    func addReservation(clients: [Client], duration: Int, includesBreakfast: Bool) throws -> Reservation {
        // Verificamos que no hay otra reserva con el mismo ID
        if reservationExists(withID: reservationIDCounter) {
            throw ReservationError.duplicateID
        }
        
        // Verificamos que no hay clientes con reservas previas
        for client in clients {
            if reservationExists(forClient: client) {
                throw ReservationError.reservationNotFoundClient
            }
        }
        
        // Calculamos el precio segun las condiciones
        let basePricePerClient = 20.0
        let breakfastMultiplier = includesBreakfast ? 1.25 : 1.0
        let price = Double(clients.count) * basePricePerClient * Double(duration) * breakfastMultiplier
        
        // Finalmente creamos la reserva y la añadimos
        let reservation = Reservation(id: reservationIDCounter, hotelName: "Hotel Luchadores", clients: clients, duration: duration, price: price, includesBreakfast: includesBreakfast)
        
        // Incrementar el contador de ID
        reservationIDCounter += 1
        
        // Agregar la reserva al listado de reservas
        reservations.append(reservation)
        
        // Devolver la reserva agregada
        return reservation
    }
    
    //A continuación, declaramos las dos funciones privadas que hemos declarado anteriormente para verificar la existencia de reservas.
    private func reservationExists(withID id: Int) -> Bool {
        return reservations.contains { $0.id == id }
    }
    
    private func reservationExists(forClient client: Client) -> Bool {
        return reservations.contains { $0.clients.contains { $0.name == client.name } }
    }
    
    //Creamos el metodo para cancelar una reserva
    func cancelReservation(byID id: Int) throws {
        guard let index = reservations.firstIndex(where: { $0.id == id }) else {
            throw ReservationError.reservationNotFound
        }
        
        reservations.remove(at: index)
    }
    
    //Ahora, vamos a declarar una propiedad para obtener el listado de las reservas actuales.
    var currentReservations: [Reservation] {
            return reservations
        }
}


// Creamos la función de prueba: testAddReservation
func testAddReservation() {
    let manager = HotelReservationManager()
    
    let goku = Client(name: "Goku", age: 30, height: 175.0)
    let vegeta = Client(name: "Vegeta", age: 35, height: 180.0)
    let krillin = Client(name: "Krillin", age: 28, height: 155.0)
    
    // Reserva válida
    do {
        let reservation = try manager.addReservation(clients: [goku, vegeta], duration: 5, includesBreakfast: true)
        print("Reserva agregada correctamente: \(reservation)")
    } catch {
        print("Error al agregar la reserva: \(error)")
    }
    
    // Reserva con ID duplicado
    do {
        let reservation = try manager.addReservation(clients: [krillin], duration: 3, includesBreakfast: false)
        print("Reserva agregada correctamente: \(reservation)")
    } catch {
        print("Error al agregar la reserva: \(error)")
    }
    
    // Reserva con cliente duplicado
    do {
        let reservation = try manager.addReservation(clients: [goku, krillin], duration: 4, includesBreakfast: true)
        print("Reserva agregada correctamente: \(reservation)")
    } catch {
        print("Error al agregar la reserva: \(error)")
    }
}

// Creamos la función de prueba: testCancelReservation
func testCancelReservation() {
    let manager = HotelReservationManager()
    
    let goku = Client(name: "Goku", age: 30, height: 175.0)
    
    do {
        let reservation = try manager.addReservation(clients: [goku], duration: 7, includesBreakfast: true)
        print("Reserva agregada correctamente: \(reservation)")
        
        try manager.cancelReservation(byID: reservation.id)
        print("Reserva cancelada correctamente")
    } catch {
        print("Error al cancelar la reserva: \(error)")
    }
    
    // Cancelar reserva inexistente
    do {
        try manager.cancelReservation(byID: 10)
        print("Reserva cancelada correctamente")
    } catch {
        print("Error al cancelar la reserva: \(error)")
    }
}

// Creamos la función de prueba: testReservationPrice
func testReservationPrice() {
    let manager = HotelReservationManager()
    
    let goku = Client(name: "Goku", age: 30, height: 175.0)
    let vegeta = Client(name: "Vegeta", age: 35, height: 180.0)
    
    do {
        let reservation1 = try manager.addReservation(clients: [goku], duration: 3, includesBreakfast: true)
        print("Reserva 1: \(reservation1)")
        
        let reservation2 = try manager.addReservation(clients: [vegeta], duration: 3, includesBreakfast: true)
        print("Reserva 2: \(reservation2)")
        
        if reservation1.price == reservation2.price {
            print("Ambas reservas tienen el mismo precio")
        } else {
            print("Las reservas tienen precios diferentes")
        }
    } catch {
        print("Error al agregar la reserva: \(error)")
    }
}

// Ejecutamos las pruebas
testAddReservation()
testCancelReservation()
testReservationPrice()


